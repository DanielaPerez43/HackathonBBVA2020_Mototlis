<?php

$hostname_conex = "localhost";
$database_conex = "mototli_huella_xoxoktli";
$username_conex = "mototli_huella_xoxoktli";
$password_conex = "Y4]CW@xE5*w6";
// creación de la conexión a la base de datos con mysql_connect()
$conn = mysqli_connect($hostname_conex, $username_conex, $password_conex, $database_conex) or 
die ("No se ha podido conectar al servidor de Base de datos"); 


?>
